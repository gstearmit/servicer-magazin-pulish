<?php
define('domain', 'http://alatca.test:2047/');
defined('WEB_PATH') ||
define('WEB_PATH','http://topprinter.net');
define('CK_BASE_PATH','/ckeditor');

defined('WEB_PATH') ||
define('WEB_PATH','http://topprinter.net');



define('ADMIN_NAME', 'phuca4@gmail.com');
define('GMAIL_USERNAME', 'gstearmit@gmail.com');
define('GMAIL_PASSWORD', '');
define('SMTP_SERVER', 'smtp.gmail.com');
define('SMTP_DEBUG_MOD', 1);
define('EMAIL_TEST', 'phuca4@gmail.com');

define('LANG_PATH', 'public/languages');
define('DEFAULT_LANGUAGE', 'en');
defined('SERVER_ENVIRONMENT') ||
define('SERVER_ENVIRONMENT','localhost');


defined('ROOT_PATH') ||
define('ROOT_PATH',
realpath(dirname(__FILE__)));
?>