<?php
return array (
	'zendcart' => array (
		'vat' => '21'
	)
);