<?php
return array(
   'db' => array(
      'username' => 'servicemz2',
      'password' => '+451bv(_Tmw{',
   ),
);

return array(
  'doctrine' => array(
    'connection' => array(
      'orm_default' => array(
        'driverClass' => 'Doctrine\DBAL\Driver\PDOMySql\Driver',
        'params' => array(
          'host'     => 'localhost',
          'port'     => '3306',
          'user'     => 'servicemz2',
          'password' => '+451bv(_Tmw{',
          'dbname'   => 'servicemz2'
        )
      )
    )
  ),
);