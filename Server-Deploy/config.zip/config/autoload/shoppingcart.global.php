<?php

return array(
    'shopping_cart' => array(
        'vat' => 25,
        'session_name' => 'shopping_cart',
    ),
);
